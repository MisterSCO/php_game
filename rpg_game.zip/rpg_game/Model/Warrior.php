<?php
namespace Model;


/**
 * Warrior
 */
final class Warrior extends Character
{

}