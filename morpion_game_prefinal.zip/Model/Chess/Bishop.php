<?php
namespace Model\Chess;

final class Bishop extends \Model\Pawn 
{
    /**@var string */
    protected const SYMBOL = '&#9815;';
       
    /**
    * @return array
    */
    public function getMoves() : array
    {
        // On prépare les groupements de coordonnées
        $aMoves = [
            0 => [],
            1 => [],
            2 => [],
            3 => [],
        ];

        // Directions
        for ($i = 1 ; $i < 8 ; $i++) {
            //array_push($aMoves[0], [$this->x - $i, $this->y - $i]);
            $aMoves[0][] = [$this->x - $i, $this->y - $i];
            $aMoves[1][] = [$this->x - $i, $this->y + $i];
            $aMoves[2][] = [$this->x + $i, $this->y - $i];
            $aMoves[3][] = [$this->x + $i, $this->y + $i];
        }

        return $aMoves;
    }
}