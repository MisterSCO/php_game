<?php
namespace Model\Chess;

final class Knight extends \Model\Pawn 
{
    /**@var string */
    protected const SYMBOL = '&#9816;';

    /**
     * @return array
     */
    public function getMoves() : array
    {
        $aMoves = [];

        // Left
        $aMoves[] = [$this->x - 1, $this->y - 2];
        $aMoves[] = [$this->x - 1, $this->y + 2];
        $aMoves[] = [$this->x - 2, $this->y - 1];
        $aMoves[] = [$this->x - 2, $this->y + 1];

        // Right
        $aMoves[] = [$this->x + 1, $this->y - 2];
        $aMoves[] = [$this->x + 1, $this->y + 2]; 
        $aMoves[] = [$this->x + 2, $this->y - 1];
        $aMoves[] = [$this->x + 2, $this->y + 1];     

        return $aMoves;
    }
}