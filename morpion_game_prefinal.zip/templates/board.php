<strong> 
    <?= $oGame->getCurrentPlayer(); ?>, c'est à toi de jouer.
    <?php /*if ($oGame && isset($aGameInfo['current_player'])): ?>
        <?= $oGame['current_player']->getName(); ?>, c'est à toi de jouer.
    <?php endif;*/ ?>
</strong>

<!-- Version 1
<?php $cpt = 'A'; ?>
<div class="row justify-content-center">
    <div class="col-auto border text-center">&nbsp;&nbsp;</div>
    <?php for ($i = 0 ; $i < count($oGame->getBoard()[0]) ; $i++): ?>   
        <div class="col-auto border text-center" style="width: 50px"><?= $cpt; ?></div>
        <?php $cpt++; ?>
    <?php endfor; ?>
</div>
-->

<!-- Version 2 -->
<?php $aLetters = range('A', 'Z'); ?>
<div class="row justify-content-center"> 
    <div class="col-auto border text-center">&nbsp;&nbsp;</div>
    <?php foreach ($oGame->getBoard()[0] as $iX => $mColX): ?>
        <div class="col-auto border text-center" style="width: 50px"><?= $aLetters[$iX]; ?></div>
    <?php endforeach; ?>
</div>

<?php
    foreach ( $oGame->getBoard() as $iY => $aLineY ): ?>
    <div class="row justify-content-center">
        <div class="col-auto border text-center" ><?= (count($oGame->getBoard())-$iY); ?></div>
        <?php foreach ( $aLineY as $iX => $mColX ): 
            //$aCellCoords = [$iX, $iY];
            //$bCellMovable = $aGameInfo && in_array($aCellCoords, $aGameInfo['moves']);
            $bCellMovable = $aGameInfo && in_array([$iX, $iY], $aGameInfo['moves']);            
            ?>
            <div class="col-auto border text-center cell <?= $bCellMovable ? 'movable-cell' : ''; ?>" 
                 data-x="<?= $iX; ?>" data-y="<?= $iY; ?>">
                <?php
                    if ($mColX instanceof \Model\Pawn) {
                        $bSelected = $aGameInfo && ($mColX === $aGameInfo['selected_pawn']);
                        echo '<span 
                                class="'. ($bSelected ? 'selected-pawn' : '') .'" 
                                style="color: '. $mColX->getPlayer()->getTeam() .';"
                              >';

                        /*
                        Solution 2
                        $sClass = '';
                        if ($aGameInfo && ($mColX === $aGameInfo['selected_pawn'])) {
                            $sClass = 'selected-pawn';
                        }
                        echo '<span 
                                class="'. $sClass .'" 
                                style="color: '. $mColX->getPlayer()->getTeam() .';"
                              >';
                        */
                    }

                    echo $mColX;

                    if ($mColX instanceof \Model\Pawn) {
                      echo '</span>';
                    }
                ?>
            </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; ?>